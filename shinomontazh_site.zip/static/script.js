const menuButton=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav');
menuButton?.addEventListener('click',()=>nav.classList.toggle('open'));
nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
document.querySelectorAll('.price-tab').forEach(tab=>{
  tab.addEventListener('click',()=>{
    document.querySelectorAll('.price-tab').forEach(t=>t.classList.remove('selected'));
    document.querySelectorAll('.price-panel').forEach(p=>p.classList.remove('visible'));
    tab.classList.add('selected');
    document.getElementById(tab.dataset.target).classList.add('visible');
  });
});
